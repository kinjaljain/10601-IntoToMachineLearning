import random
import time

def generate_subsets(n): 
    """[1, 2, 3] => [[], [1], [2], [3], [1, 2], ... [1, 2, 3]]"""
    if (n == 0): return [[]]
    else: 
        subsets = []
        for subset in generate_subsets(n-1): 
            subsets.append(subset)
            subsets.append(subset + [n])
    return subsets

def knapsack_bruteforce(W, weights, values): 
    n = len(weights)

    # generating all subsets
    subsets = generate_subsets(n)

    # get the max sum of all subsets
    max_val = 0
    for subset in subsets: 
        cur_weights = sum([weights[i-1] for i in subset])
        if (cur_weights <= W): 
            cur_val = sum([values[i-1] for i in subset])
            if (cur_val > max_val): max_val = cur_val
    return max_val

def knapsack(W, weights, values):
    n = len(weights)
    chart = [[0 for _ in range(W+1)] for _ in range(n+1)]
    for i in range(1, n+1): 
        for sum_w in range(W+1):
            if (weights[i-1] <= sum_w): # if the current item weight does not exceed the sum weight in the knapsack 
                chart[i][sum_w] = max(values[i-1] + chart[i-1][sum_w - weights[i-1]], chart[i-1][sum_w])
            else: # else, it's already full
                chart[i][sum_w] = chart[i-1][sum_w]
    
    return chart[n][W]
    
def correctness_test(): 
    print("Checking correctness of knapsack on small example...", end="")
    W = 100
    w = [10, 50, 60]
    v = [100, 200, 300]
    assert(knapsack_bruteforce(W, w, v) == 400)
    assert(knapsack(W, w, v) == 400)
    print("Done!")

def time_test(): 
    print("Timing experiments")
    n = 20 # number of items (up to 20 is already fine, as brute force would take complexity O(2**20)!)
    W = 100
    w = [random.randint(1, 10) for _ in range(n)] 
    v = [random.randint(1, 10) for _ in range(n)]
    start = time.time()
    dp_val = knapsack(W, w, v)
    print("Knapsack DP returns %d using %f s" % (dp_val, time.time()-start))
    start = time.time()
    bf_val = knapsack_bruteforce(W, w, v)
    print("Knapsack Brute Force returns %d using %f s" % (dp_val, time.time()-start))


if __name__ == "__main__":
    correctness_test()
    time_test()